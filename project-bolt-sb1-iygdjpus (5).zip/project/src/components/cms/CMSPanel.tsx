import React, { useState } from 'react';
import { X, User, Briefcase, FolderOpen, Save, Sparkles, Check } from 'lucide-react';
import { useCMS } from '../../contexts/CMSContext';
import PersonalInfoEditor from './PersonalInfoEditor';
import ServicesEditor from './ServicesEditor';
import PortfolioEditor from './PortfolioEditor';

const CMSPanel: React.FC = () => {
  const { isAdmin, setIsAdmin, data, updateData } = useCMS();
  const [activeTab, setActiveTab] = useState<'personal' | 'services' | 'portfolio'>('personal');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isAdmin) return null;

  const tabs = [
    { id: 'personal', label: 'Personal Info', icon: User },
    { id: 'services', label: 'Services', icon: Briefcase },
    { id: 'portfolio', label: 'Portfolio', icon: FolderOpen },
  ];

  const handleSaveAll = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    
    try {
      // Save current data to localStorage
      localStorage.setItem('cmsData', JSON.stringify(data));
      
      // Simulate save process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error('Save failed:', error);
      alert('Save failed. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/95 backdrop-blur-sm z-50 overflow-hidden">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="flex-shrink-0 flex items-center justify-between p-6 border-b border-gray-700/50 bg-gray-900/95 backdrop-blur-xl">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Content Management System</h2>
              <p className="text-sm text-gray-400">Manage your website content</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleSaveAll}
              disabled={isSaving}
              className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                saveSuccess
                  ? 'bg-green-600 text-white'
                  : isSaving
                  ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white hover:from-emerald-700 hover:to-teal-700 hover:scale-105 shadow-lg'
              }`}
            >
              {saveSuccess ? (
                <>
                  <Check size={16} />
                  <span>Saved!</span>
                </>
              ) : isSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Save size={16} />
                  <span>Save All Changes</span>
                </>
              )}
            </button>
            <button
              onClick={() => setIsAdmin(false)}
              className="p-3 hover:bg-gray-700/50 rounded-xl transition-colors duration-200 text-gray-400 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        <div className="flex-1 flex min-h-0">
          {/* Sidebar */}
          <div className="flex-shrink-0 w-80 border-r border-gray-700/50 bg-gray-800/50 overflow-y-auto">
            <div className="p-6">
              <nav className="space-y-2 mb-8">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`w-full flex items-center space-x-4 px-6 py-4 rounded-xl text-left transition-all duration-300 ${
                      activeTab === tab.id
                        ? 'bg-gradient-to-r from-blue-600/30 to-purple-600/30 text-white border border-blue-500/50 shadow-lg'
                        : 'hover:bg-gray-700/30 text-gray-400 hover:text-white'
                    }`}
                  >
                    <tab.icon size={20} />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                ))}
              </nav>

              {/* Quick Stats */}
              <div className="p-6 bg-gray-800/80 rounded-xl border border-gray-700/50 backdrop-blur-sm">
                <h4 className="text-sm font-semibold text-gray-300 mb-4 flex items-center">
                  <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                  Quick Stats
                </h4>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Services</span>
                    <span className="text-blue-400 font-semibold bg-blue-400/10 px-2 py-1 rounded-lg">
                      {data.services.length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Portfolio Items</span>
                    <span className="text-emerald-400 font-semibold bg-emerald-400/10 px-2 py-1 rounded-lg">
                      {data.portfolio.length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Last Updated</span>
                    <span className="text-purple-400 font-semibold bg-purple-400/10 px-2 py-1 rounded-lg">
                      {new Date().toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto bg-gray-900/30">
            <div className="p-8 max-w-6xl">
              {activeTab === 'personal' && <PersonalInfoEditor />}
              {activeTab === 'services' && <ServicesEditor />}
              {activeTab === 'portfolio' && <PortfolioEditor />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CMSPanel;
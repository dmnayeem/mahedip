import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Save, X, Check, FolderOpen, Upload, Image } from 'lucide-react';
import { useCMS } from '../../contexts/CMSContext';
import { PortfolioItem } from '../../types';

const PortfolioEditor: React.FC = () => {
  const { data, updateData } = useCMS();
  const [editingItem, setEditingItem] = useState<PortfolioItem | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const emptyItem: PortfolioItem = {
    id: '',
    title: '',
    description: '',
    category: '',
    image: '',
    results: [],
    link: ''
  };

  const handleCreateItem = () => {
    setEditingItem(emptyItem);
    setIsCreating(true);
  };

  const handleEditItem = (item: PortfolioItem) => {
    setEditingItem(item);
    setIsCreating(false);
  };

  const handleSaveItem = async (item: PortfolioItem) => {
    setIsLoading(true);
    try {
      if (isCreating) {
        const newItem = { ...item, id: Date.now().toString() };
        updateData({ portfolio: [...data.portfolio, newItem] });
      } else {
        const updatedPortfolio = data.portfolio.map(p => 
          p.id === item.id ? item : p
        );
        updateData({ portfolio: updatedPortfolio });
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
      setEditingItem(null);
      setIsCreating(false);
    } catch (error) {
      console.error('Save failed:', error);
      alert('Save failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteItem = (id: string) => {
    if (confirm('Are you sure you want to delete this portfolio item? This action cannot be undone.')) {
      const updatedPortfolio = data.portfolio.filter(p => p.id !== id);
      updateData({ portfolio: updatedPortfolio });
    }
  };

  const handleCancel = () => {
    setEditingItem(null);
    setIsCreating(false);
  };

  const categoryColors = {
    'E-commerce': 'from-blue-500 to-cyan-400',
    'Local Business': 'from-emerald-500 to-teal-400',
    'SaaS': 'from-purple-500 to-pink-400',
    'Healthcare': 'from-orange-500 to-red-400',
    'Technology': 'from-indigo-500 to-purple-400',
    'Finance': 'from-green-500 to-emerald-400'
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center">
            <FolderOpen size={20} className="text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">Portfolio Management</h3>
            <p className="text-gray-400">Showcase your best work and achievements</p>
          </div>
        </div>
        <button
          onClick={handleCreateItem}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
        >
          <Plus size={20} />
          <span>Add Portfolio Item</span>
        </button>
      </div>

      {editingItem && (
        <PortfolioForm
          item={editingItem}
          onSave={handleSaveItem}
          onCancel={handleCancel}
          isCreating={isCreating}
          isLoading={isLoading}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {data.portfolio.map((item) => {
          const categoryColor = categoryColors[item.category as keyof typeof categoryColors] || 'from-gray-500 to-gray-400';
          
          return (
            <div key={item.id} className="bg-gray-800/50 border border-gray-700/50 rounded-2xl overflow-hidden hover:bg-gray-700/30 transition-all duration-300 group">
              <div className="relative">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                
                {/* Category Badge */}
                <div className="absolute top-4 right-4">
                  <span className={`bg-gradient-to-r ${categoryColor} text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg`}>
                    {item.category}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="absolute top-4 left-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button
                    onClick={() => handleEditItem(item)}
                    className="p-2 bg-blue-600/80 hover:bg-blue-600 text-white rounded-lg transition-all duration-200 backdrop-blur-sm"
                    title="Edit Portfolio Item"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button
                    onClick={() => handleDeleteItem(item.id)}
                    className="p-2 bg-red-600/80 hover:bg-red-600 text-white rounded-lg transition-all duration-200 backdrop-blur-sm"
                    title="Delete Portfolio Item"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                <h4 className="text-xl font-semibold text-white mb-2 group-hover:text-blue-300 transition-colors duration-300">
                  {item.title}
                </h4>
                <p className="text-gray-300 mb-4 leading-relaxed line-clamp-2">{item.description}</p>
                
                <div className="space-y-3">
                  <h5 className="font-semibold text-white flex items-center">
                    <div className={`w-2 h-2 bg-gradient-to-r ${categoryColor} rounded-full mr-2`}></div>
                    Key Results ({item.results.length})
                  </h5>
                  <div className="space-y-2 max-h-24 overflow-y-auto">
                    {item.results.slice(0, 3).map((result, index) => (
                      <div key={index} className="flex items-center text-sm text-gray-400 bg-gray-700/30 px-3 py-2 rounded-lg">
                        <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full mr-3 flex-shrink-0"></div>
                        <span className="truncate">{result}</span>
                      </div>
                    ))}
                    {item.results.length > 3 && (
                      <p className="text-xs text-gray-500 px-3">+{item.results.length - 3} more results</p>
                    )}
                  </div>
                </div>

                {item.link && (
                  <div className="mt-4 pt-4 border-t border-gray-700/50">
                    <a
                      href={item.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors duration-300"
                    >
                      View Case Study →
                    </a>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {data.portfolio.length === 0 && (
        <div className="text-center py-16 bg-gray-800/30 rounded-2xl border border-gray-700/50">
          <FolderOpen size={48} className="text-gray-500 mx-auto mb-4" />
          <h4 className="text-xl font-semibold text-gray-400 mb-2">No Portfolio Items</h4>
          <p className="text-gray-500 mb-6">Start showcasing your work by adding your first portfolio item.</p>
          <button
            onClick={handleCreateItem}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300"
          >
            Add Your First Project
          </button>
        </div>
      )}
    </div>
  );
};

interface PortfolioFormProps {
  item: PortfolioItem;
  onSave: (item: PortfolioItem) => void;
  onCancel: () => void;
  isCreating: boolean;
  isLoading?: boolean;
}

const PortfolioForm: React.FC<PortfolioFormProps> = ({ item, onSave, onCancel, isCreating, isLoading = false }) => {
  const [formData, setFormData] = useState(item);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.description.trim() || !formData.category.trim() || !formData.image.trim()) {
      alert('Please fill in all required fields.');
      return;
    }
    onSave(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleResultsChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const results = e.target.value.split('\n').map(r => r.trim()).filter(r => r);
    setFormData({ ...formData, results });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string;
        setFormData({ ...formData, image: imageUrl });
      };
      reader.readAsDataURL(file);
    }
  };

  const categories = ['E-commerce', 'Local Business', 'SaaS', 'Healthcare', 'Technology', 'Finance'];
  
  const suggestedImages = [
    'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
    'https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
    'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
    'https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
    'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
    'https://images.pexels.com/photos/590016/pexels-photo-590016.jpg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
  ];

  return (
    <div className="bg-gray-800/50 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8 mb-8">
      <div className="flex items-center justify-between mb-6">
        <h4 className="text-xl font-semibold text-white">
          {isCreating ? 'Create New Portfolio Item' : 'Edit Portfolio Item'}
        </h4>
        <button
          onClick={onCancel}
          className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-lg transition-all duration-200"
        >
          <X size={20} />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Project Image Section */}
        <div className="space-y-6">
          <h5 className="text-lg font-semibold text-white flex items-center">
            <Image size={20} className="mr-2 text-blue-400" />
            Project Image
          </h5>
          
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Current Image Preview */}
            <div className="flex-shrink-0">
              <div className="w-64 h-40 rounded-xl overflow-hidden border-2 border-gray-600/50 bg-gray-700/50">
                {formData.image ? (
                  <img
                    src={formData.image}
                    alt="Project preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400">
                    <Image size={32} />
                  </div>
                )}
              </div>
            </div>

            {/* Image Upload Options */}
            <div className="flex-1 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">
                  Upload Project Image
                </label>
                <div className="flex items-center space-x-4">
                  <label className="flex items-center space-x-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl cursor-pointer transition-colors duration-300">
                    <Upload size={16} />
                    <span>Choose File</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                  <span className="text-sm text-gray-400">JPG, PNG, GIF up to 5MB</span>
                </div>
              </div>

              <div>
                <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-300 mb-3">
                  Or Enter Image URL *
                </label>
                <input
                  type="url"
                  id="imageUrl"
                  name="image"
                  value={formData.image}
                  onChange={handleInputChange}
                  required
                  placeholder="https://example.com/project-image.jpg"
                  className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300"
                />
              </div>

              {/* Suggested Images */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">
                  Or Choose from Suggestions
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {suggestedImages.map((imageUrl, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => setFormData({ ...formData, image: imageUrl })}
                      className={`relative w-full h-20 rounded-lg overflow-hidden border-2 transition-all duration-300 ${
                        formData.image === imageUrl
                          ? 'border-blue-500 ring-2 ring-blue-500/30'
                          : 'border-gray-600/50 hover:border-gray-500'
                      }`}
                    >
                      <img
                        src={imageUrl}
                        alt={`Suggestion ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      {formData.image === imageUrl && (
                        <div className="absolute inset-0 bg-blue-500/20 flex items-center justify-center">
                          <Check size={16} className="text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Basic Information */}
        <div className="space-y-6">
          <h5 className="text-lg font-semibold text-white">Project Information</h5>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-3">
                Project Title *
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300"
                placeholder="e.g., E-commerce Growth Campaign"
              />
            </div>
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-300 mb-3">
                Category *
              </label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white transition-all duration-300"
              >
                <option value="">Select a category</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-3">
              Project Description *
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              required
              rows={4}
              className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300 resize-none"
              placeholder="Describe the project, challenges faced, and solutions implemented..."
            />
          </div>

          <div>
            <label htmlFor="link" className="block text-sm font-medium text-gray-300 mb-3">
              Case Study Link (optional)
            </label>
            <input
              type="url"
              id="link"
              name="link"
              value={formData.link}
              onChange={handleInputChange}
              className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300"
              placeholder="https://example.com/case-study"
            />
          </div>
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          <h5 className="text-lg font-semibold text-white">Project Results</h5>
          <div>
            <label htmlFor="results" className="block text-sm font-medium text-gray-300 mb-3">
              Key Results & Achievements (one per line)
            </label>
            <textarea
              id="results"
              value={formData.results.join('\n')}
              onChange={handleResultsChange}
              rows={6}
              className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300 resize-none"
              placeholder="300% increase in online sales&#10;150% growth in organic traffic&#10;40% improvement in conversion rate&#10;Generated 500+ qualified leads"
            />
            <p className="text-xs text-gray-500 mt-2">Enter each result on a new line. Include specific numbers and percentages when possible.</p>
          </div>
        </div>

        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-700/50">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-3 bg-gray-600 text-white rounded-xl hover:bg-gray-700 transition-all duration-300"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isLoading}
            className={`flex items-center space-x-2 px-8 py-3 rounded-xl font-semibold transition-all duration-300 ${
              isLoading
                ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 hover:scale-105 shadow-lg hover:shadow-xl'
            }`}
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                <span>Saving...</span>
              </>
            ) : (
              <>
                <Save size={16} />
                <span>{isCreating ? 'Create Portfolio Item' : 'Update Portfolio Item'}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PortfolioEditor;
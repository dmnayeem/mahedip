import React from 'react';
import { Award, Users, TrendingUp, Sparkles, Zap, Target } from 'lucide-react';
import { useCMS } from '../contexts/CMSContext';

const About: React.FC = () => {
  const { data } = useCMS();

  const stats = [
    {
      icon: TrendingUp,
      value: "300%",
      label: "Average ROI Increase",
      description: "Average return on investment for client campaigns",
      color: "from-blue-500 to-cyan-400"
    },
    {
      icon: Users,
      value: "50+",
      label: "Happy Clients",
      description: "Successful projects completed across various industries",
      color: "from-purple-500 to-pink-400"
    },
    {
      icon: Award,
      value: data.personalInfo.experience,
      label: "Experience",
      description: "Years of expertise in digital marketing",
      color: "from-emerald-500 to-teal-400"
    }
  ];

  return (
    <section id="about" className="py-24 bg-gray-900 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-20">
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-full border border-blue-500/30 backdrop-blur-sm mb-6">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-blue-300 font-medium">About Me</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Passionate About{' '}
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-emerald-400 bg-clip-text text-transparent">
              Digital Growth
            </span>
          </h2>
          <p className="text-xl text-gray-400 leading-relaxed">
            Driving digital transformation and helping businesses achieve their online goals through strategic marketing solutions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={stat.label} className="group relative">
              <div className="relative bg-gray-800/50 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8 hover:bg-gray-700/50 transition-all duration-500 hover:scale-105">
                <div className="absolute inset-0 bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                <div className="relative z-10 text-center">
                  <div className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br ${stat.color} rounded-2xl mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <stat.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-4xl font-bold text-white mb-2 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 group-hover:bg-clip-text transition-all duration-300">
                    {stat.value}
                  </h3>
                  <p className="text-xl font-semibold text-gray-300 mb-3">{stat.label}</p>
                  <p className="text-sm text-gray-500">{stat.description}</p>
                </div>

                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} rounded-2xl blur-xl opacity-0 group-hover:opacity-20 transition-opacity duration-500 -z-10`}></div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="flex items-center space-x-3">
                <Target className="w-6 h-6 text-blue-400" />
                <h3 className="text-3xl font-bold text-white">My Expertise</h3>
              </div>
              <p className="text-gray-400 leading-relaxed text-lg">
                With {data.personalInfo.experience} of experience in digital marketing, I specialize in creating data-driven strategies that deliver measurable results. My approach combines creativity with analytics to ensure every campaign not only engages your audience but also drives real business growth.
              </p>
              <p className="text-gray-400 leading-relaxed text-lg">
                I stay updated with the latest digital marketing trends and technologies to provide cutting-edge solutions that keep my clients ahead of the competition.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              {['Strategy', 'Analytics', 'Growth', 'Innovation'].map((tag, index) => (
                <span key={tag} className="px-4 py-2 bg-gradient-to-r from-blue-600/20 to-purple-600/20 text-blue-300 rounded-full text-sm font-medium border border-blue-500/30 backdrop-blur-sm">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <div className="flex items-center space-x-3">
              <Zap className="w-6 h-6 text-emerald-400" />
              <h3 className="text-3xl font-bold text-white">Core Skills</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {data.personalInfo.skills.map((skill, index) => (
                <div key={index} className="group relative">
                  <div className="flex items-center space-x-4 p-4 bg-gray-800/50 backdrop-blur-xl border border-gray-700/50 rounded-xl hover:bg-gray-700/50 transition-all duration-300 hover:scale-105">
                    <div className="w-3 h-3 bg-gradient-to-br from-emerald-400 to-blue-400 rounded-full group-hover:animate-pulse"></div>
                    <span className="text-gray-300 font-medium group-hover:text-white transition-colors duration-300">{skill}</span>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 to-blue-500/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10 blur-lg"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
import { CMSData } from '../types';

export const initialData: CMSData = {
  personalInfo: {
    name: "Sheikh Mahedi Hasan",
    title: "Digital Marketing Expert",
    bio: "I am a passionate digital marketing expert with over 5 years of experience in helping businesses grow their online presence. I specialize in SEO, social media marketing, PPC advertising, and content strategy. My goal is to deliver measurable results that drive revenue and brand awareness for my clients.",
    image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=500&h=500&fit=crop",
    email: "sheikh.mahedi@email.com",
    phone: "+1 (555) 123-4567",
    location: "New York, NY",
    skills: ["SEO", "Google Ads", "Social Media Marketing", "Content Strategy", "Analytics", "Email Marketing"],
    experience: "5+ Years"
  },
  services: [
    {
      id: "seo",
      title: "Search Engine Optimization",
      description: "Boost your website's visibility and organic traffic with proven SEO strategies.",
      icon: "Search",
      features: ["Keyword Research", "On-Page Optimization", "Technical SEO", "Link Building", "Local SEO"]
    },
    {
      id: "ppc",
      title: "PPC Advertising",
      description: "Drive targeted traffic and maximize ROI with strategic paid advertising campaigns.",
      icon: "Target",
      features: ["Google Ads", "Facebook Ads", "Campaign Optimization", "Landing Page Design", "Conversion Tracking"]
    },
    {
      id: "social",
      title: "Social Media Marketing",
      description: "Build brand awareness and engage your audience across social platforms.",
      icon: "Users",
      features: ["Content Creation", "Community Management", "Social Media Strategy", "Influencer Marketing", "Analytics"]
    },
    {
      id: "content",
      title: "Content Strategy",
      description: "Create compelling content that resonates with your audience and drives results.",
      icon: "FileText",
      features: ["Content Planning", "Blog Writing", "Video Marketing", "Email Campaigns", "Brand Storytelling"]
    },
    {
      id: "analytics",
      title: "Analytics & Reporting",
      description: "Track performance and optimize campaigns with data-driven insights.",
      icon: "BarChart3",
      features: ["Google Analytics", "Performance Tracking", "Custom Reports", "ROI Analysis", "Conversion Optimization"]
    },
    {
      id: "consulting",
      title: "Digital Marketing Consulting",
      description: "Get expert guidance and strategic planning for your digital marketing efforts.",
      icon: "MessageCircle",
      features: ["Strategy Development", "Marketing Audits", "Training Sessions", "Growth Planning", "Competitive Analysis"]
    }
  ],
  portfolio: [
    {
      id: "ecommerce-growth",
      title: "E-commerce Growth Campaign",
      description: "Helped a fashion retailer increase online sales by 300% through integrated digital marketing.",
      category: "E-commerce",
      image: "https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      results: ["300% increase in online sales", "150% growth in organic traffic", "40% improvement in conversion rate"],
      link: "#"
    },
    {
      id: "local-business",
      title: "Local Restaurant Marketing",
      description: "Boosted local restaurant's visibility and customer base through targeted local SEO and social media.",
      category: "Local Business",
      image: "https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      results: ["200% increase in local visibility", "80% growth in online orders", "500+ new social media followers"],
      link: "#"
    },
    {
      id: "saas-leads",
      title: "SaaS Lead Generation",
      description: "Generated high-quality leads for B2B SaaS company through content marketing and PPC campaigns.",
      category: "SaaS",
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      results: ["400% increase in qualified leads", "50% reduction in cost per lead", "35% improvement in conversion rate"],
      link: "#"
    },
    {
      id: "healthcare-brand",
      title: "Healthcare Brand Awareness",
      description: "Built comprehensive digital presence for healthcare clinic, establishing trust and credibility.",
      category: "Healthcare",
      image: "https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      results: ["250% increase in website traffic", "90% growth in appointment bookings", "85% improvement in brand awareness"],
      link: "#"
    }
  ]
};
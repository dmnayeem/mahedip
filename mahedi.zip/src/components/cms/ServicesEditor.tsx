import React, { useState } from 'react';
import { Plus, Edit2, Trash2, Save, X, Check, Briefcase } from 'lucide-react';
import { useCMS } from '../../contexts/CMSContext';
import { Service } from '../../types';

const ServicesEditor: React.FC = () => {
  const { data, updateData } = useCMS();
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const emptyService: Service = {
    id: '',
    title: '',
    description: '',
    icon: 'Star',
    features: []
  };

  const handleCreateService = () => {
    setEditingService(emptyService);
    setIsCreating(true);
  };

  const handleEditService = (service: Service) => {
    setEditingService(service);
    setIsCreating(false);
  };

  const handleSaveService = async (service: Service) => {
    setIsLoading(true);
    try {
      if (isCreating) {
        const newService = { ...service, id: Date.now().toString() };
        updateData({ services: [...data.services, newService] });
      } else {
        const updatedServices = data.services.map(s => 
          s.id === service.id ? service : s
        );
        updateData({ services: updatedServices });
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
      setEditingService(null);
      setIsCreating(false);
    } catch (error) {
      console.error('Save failed:', error);
      alert('Save failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteService = (id: string) => {
    if (confirm('Are you sure you want to delete this service? This action cannot be undone.')) {
      const updatedServices = data.services.filter(s => s.id !== id);
      updateData({ services: updatedServices });
    }
  };

  const handleCancel = () => {
    setEditingService(null);
    setIsCreating(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
            <Briefcase size={20} className="text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">Services Management</h3>
            <p className="text-gray-400">Add, edit, or remove your services</p>
          </div>
        </div>
        <button
          onClick={handleCreateService}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
        >
          <Plus size={20} />
          <span>Add New Service</span>
        </button>
      </div>

      {editingService && (
        <ServiceForm
          service={editingService}
          onSave={handleSaveService}
          onCancel={handleCancel}
          isCreating={isCreating}
          isLoading={isLoading}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {data.services.map((service, index) => (
          <div key={service.id} className="bg-gray-800/50 border border-gray-700/50 rounded-2xl p-6 hover:bg-gray-700/30 transition-all duration-300 group">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className={`w-12 h-12 bg-gradient-to-br ${
                  ['from-blue-500 to-cyan-400', 'from-purple-500 to-pink-400', 'from-emerald-500 to-teal-400', 'from-orange-500 to-red-400', 'from-indigo-500 to-purple-400', 'from-green-500 to-emerald-400'][index % 6]
                } rounded-xl flex items-center justify-center shadow-lg`}>
                  <span className="text-white font-semibold">{index + 1}</span>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white group-hover:text-blue-300 transition-colors duration-300">
                    {service.title}
                  </h4>
                  <p className="text-sm text-gray-400">Icon: {service.icon}</p>
                </div>
              </div>
              <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <button
                  onClick={() => handleEditService(service)}
                  className="p-2 text-gray-400 hover:text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all duration-200"
                  title="Edit Service"
                >
                  <Edit2 size={16} />
                </button>
                <button
                  onClick={() => handleDeleteService(service.id)}
                  className="p-2 text-gray-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all duration-200"
                  title="Delete Service"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            
            <p className="text-gray-300 mb-4 leading-relaxed">{service.description}</p>
            
            <div className="space-y-3">
              <h5 className="font-semibold text-white flex items-center">
                <div className="w-2 h-2 bg-blue-400 rounded-full mr-2"></div>
                Features ({service.features.length})
              </h5>
              <div className="grid grid-cols-1 gap-2 max-h-32 overflow-y-auto">
                {service.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center text-sm text-gray-400 bg-gray-700/30 px-3 py-2 rounded-lg">
                    <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full mr-3 flex-shrink-0"></div>
                    <span className="truncate">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {data.services.length === 0 && (
        <div className="text-center py-16 bg-gray-800/30 rounded-2xl border border-gray-700/50">
          <Briefcase size={48} className="text-gray-500 mx-auto mb-4" />
          <h4 className="text-xl font-semibold text-gray-400 mb-2">No Services Added</h4>
          <p className="text-gray-500 mb-6">Start by adding your first service to showcase your expertise.</p>
          <button
            onClick={handleCreateService}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300"
          >
            Add Your First Service
          </button>
        </div>
      )}
    </div>
  );
};

interface ServiceFormProps {
  service: Service;
  onSave: (service: Service) => void;
  onCancel: () => void;
  isCreating: boolean;
  isLoading?: boolean;
}

const ServiceForm: React.FC<ServiceFormProps> = ({ service, onSave, onCancel, isCreating, isLoading = false }) => {
  const [formData, setFormData] = useState(service);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.description.trim()) {
      alert('Please fill in all required fields.');
      return;
    }
    onSave(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFeaturesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const features = e.target.value.split('\n').map(f => f.trim()).filter(f => f);
    setFormData({ ...formData, features });
  };

  const commonIcons = [
    'Star', 'Search', 'Target', 'Users', 'FileText', 'BarChart3', 'MessageCircle', 
    'Zap', 'Shield', 'Globe', 'Smartphone', 'Mail', 'TrendingUp', 'Award'
  ];

  return (
    <div className="bg-gray-800/50 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-8 mb-8">
      <div className="flex items-center justify-between mb-6">
        <h4 className="text-xl font-semibold text-white">
          {isCreating ? 'Create New Service' : 'Edit Service'}
        </h4>
        <button
          onClick={onCancel}
          className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-lg transition-all duration-200"
        >
          <X size={20} />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-3">
              Service Title *
            </label>
            <input
              type="text"
              id="title"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              required
              className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300"
              placeholder="e.g., Search Engine Optimization"
            />
          </div>
          <div>
            <label htmlFor="icon" className="block text-sm font-medium text-gray-300 mb-3">
              Icon (Lucide React name) *
            </label>
            <select
              id="icon"
              name="icon"
              value={formData.icon}
              onChange={handleInputChange}
              required
              className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white transition-all duration-300"
            >
              {commonIcons.map(icon => (
                <option key={icon} value={icon}>{icon}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-3">
            Service Description *
          </label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            required
            rows={4}
            className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300 resize-none"
            placeholder="Describe what this service includes and how it benefits clients..."
          />
        </div>

        <div>
          <label htmlFor="features" className="block text-sm font-medium text-gray-300 mb-3">
            Service Features (one per line)
          </label>
          <textarea
            id="features"
            value={formData.features.join('\n')}
            onChange={handleFeaturesChange}
            rows={6}
            className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400 transition-all duration-300 resize-none"
            placeholder="Keyword Research&#10;On-Page Optimization&#10;Technical SEO&#10;Link Building&#10;Local SEO"
          />
          <p className="text-xs text-gray-500 mt-2">Enter each feature on a new line</p>
        </div>

        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-700/50">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-3 bg-gray-600 text-white rounded-xl hover:bg-gray-700 transition-all duration-300"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isLoading}
            className={`flex items-center space-x-2 px-8 py-3 rounded-xl font-semibold transition-all duration-300 ${
              isLoading
                ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 hover:scale-105 shadow-lg hover:shadow-xl'
            }`}
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                <span>Saving...</span>
              </>
            ) : (
              <>
                <Save size={16} />
                <span>{isCreating ? 'Create Service' : 'Update Service'}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ServicesEditor;
import React from 'react';
import { Mail, Phone, MapPin, Heart, Sparkles, Github, Linkedin, Twitter } from 'lucide-react';
import { useCMS } from '../contexts/CMSContext';

const Footer: React.FC = () => {
  const { data } = useCMS();

  const socialLinks = [
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Twitter, href: '#', label: 'Twitter' }
  ];

  return (
    <footer className="bg-gray-900 border-t border-gray-800/50 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="py-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            {/* Brand Section */}
            <div className="md:col-span-2 space-y-6">
              <div className="flex items-center space-x-3 group">
                <div className="relative">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-400 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/25 group-hover:shadow-blue-500/40 transition-all duration-300 group-hover:scale-105">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-400 rounded-xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-300"></div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                    {data.personalInfo.name}
                  </h3>
                  <p className="text-sm text-gray-400 font-medium">{data.personalInfo.title}</p>
                </div>
              </div>
              <p className="text-gray-400 leading-relaxed max-w-md">
                Transforming businesses through strategic digital marketing solutions. Let's create something extraordinary together.
              </p>
              
              {/* Social Links */}
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    className="group w-12 h-12 bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-xl flex items-center justify-center hover:bg-gray-700/50 transition-all duration-300 hover:scale-110"
                    aria-label={social.label}
                  >
                    <social.icon className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors duration-300" />
                  </a>
                ))}
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <h4 className="text-xl font-bold text-white">Contact</h4>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-sm text-gray-400 hover:text-gray-300 transition-colors duration-300 group">
                  <Mail size={16} className="text-blue-400 group-hover:text-blue-300 transition-colors duration-300" />
                  <span>{data.personalInfo.email}</span>
                </div>
                <div className="flex items-center space-x-3 text-sm text-gray-400 hover:text-gray-300 transition-colors duration-300 group">
                  <Phone size={16} className="text-emerald-400 group-hover:text-emerald-300 transition-colors duration-300" />
                  <span>{data.personalInfo.phone}</span>
                </div>
                <div className="flex items-center space-x-3 text-sm text-gray-400 hover:text-gray-300 transition-colors duration-300 group">
                  <MapPin size={16} className="text-purple-400 group-hover:text-purple-300 transition-colors duration-300" />
                  <span>{data.personalInfo.location}</span>
                </div>
              </div>
            </div>

            {/* Services */}
            <div className="space-y-6">
              <h4 className="text-xl font-bold text-white">Services</h4>
              <div className="space-y-3">
                {data.services.slice(0, 4).map((service) => (
                  <button
                    key={service.id}
                    onClick={() => document.querySelector('#services')?.scrollIntoView({ behavior: 'smooth' })}
                    className="block text-sm text-gray-400 hover:text-white transition-colors duration-300 text-left"
                  >
                    {service.title}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800/50 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <p className="text-sm text-gray-400 flex items-center space-x-2">
              <span>© {new Date().getFullYear()} {data.personalInfo.name}. Made with</span>
              <Heart size={16} className="text-red-500 animate-pulse" />
              <span>for growing businesses.</span>
            </p>
            
            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <button className="hover:text-white transition-colors duration-300">Privacy Policy</button>
              <button className="hover:text-white transition-colors duration-300">Terms of Service</button>
              <button className="hover:text-white transition-colors duration-300">Cookies</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
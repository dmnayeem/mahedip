import React from 'react';
import { ChevronDown, Mail, Phone, MapPin, Sparkles, Zap, Star } from 'lucide-react';
import { useCMS } from '../contexts/CMSContext';

const Hero: React.FC = () => {
  const { data } = useCMS();

  const scrollToAbout = () => {
    const element = document.querySelector('#about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gray-900 relative overflow-hidden pt-20">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-purple-900/20 to-emerald-900/20"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 animate-float">
          <Sparkles className="w-6 h-6 text-blue-400/30" />
        </div>
        <div className="absolute top-40 right-20 animate-float-delayed">
          <Zap className="w-8 h-8 text-purple-400/30" />
        </div>
        <div className="absolute bottom-40 left-20 animate-float-slow">
          <Star className="w-5 h-5 text-emerald-400/30" />
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 animate-fade-in-up">
            <div className="space-y-6">
              <div className="inline-flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-full border border-blue-500/30 backdrop-blur-sm">
                <Sparkles className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-blue-300 font-medium">Digital Marketing Expert</span>
              </div>
              
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight">
                <span className="text-white">Hi, I'm </span>
                <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-emerald-400 bg-clip-text text-transparent animate-gradient">
                  {data.personalInfo.name}
                </span>
              </h1>
              
              <p className="text-2xl sm:text-3xl text-gray-300 font-semibold">
                <span className="bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent">
                  {data.personalInfo.title}
                </span>
              </p>
              
              <p className="text-lg text-gray-400 leading-relaxed max-w-2xl">
                {data.personalInfo.bio}
              </p>
            </div>

            <div className="flex flex-wrap gap-6">
              <div className="flex items-center space-x-3 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700/50 backdrop-blur-sm hover:bg-gray-700/50 transition-all duration-300">
                <Mail size={16} className="text-blue-400" />
                <span className="text-sm text-gray-300">{data.personalInfo.email}</span>
              </div>
              <div className="flex items-center space-x-3 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700/50 backdrop-blur-sm hover:bg-gray-700/50 transition-all duration-300">
                <Phone size={16} className="text-emerald-400" />
                <span className="text-sm text-gray-300">{data.personalInfo.phone}</span>
              </div>
              <div className="flex items-center space-x-3 px-4 py-2 bg-gray-800/50 rounded-lg border border-gray-700/50 backdrop-blur-sm hover:bg-gray-700/50 transition-all duration-300">
                <MapPin size={16} className="text-purple-400" />
                <span className="text-sm text-gray-300">{data.personalInfo.location}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="group relative px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-2xl shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-105"
              >
                <span className="relative z-10">Get In Touch</span>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-300"></div>
              </button>
              <button
                onClick={() => document.querySelector('#portfolio')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-4 border-2 border-gray-600 text-gray-300 rounded-xl font-semibold hover:border-gray-500 hover:text-white hover:bg-gray-800/50 transition-all duration-300 backdrop-blur-sm"
              >
                View Portfolio
              </button>
            </div>
          </div>

          <div className="relative animate-fade-in-right">
            <div className="relative z-10 group">
              <div className="relative overflow-hidden rounded-3xl">
                <img
                  src={data.personalInfo.image}
                  alt={data.personalInfo.name}
                  className="w-full max-w-lg mx-auto rounded-3xl shadow-2xl group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/50 to-transparent rounded-3xl"></div>
              </div>
              
              {/* Floating Cards */}
              <div className="absolute -top-6 -left-6 bg-gray-800/90 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-4 shadow-2xl animate-float">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse"></div>
                  <span className="text-sm text-gray-300 font-medium">Available for Projects</span>
                </div>
              </div>
              
              <div className="absolute -bottom-6 -right-6 bg-gray-800/90 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-4 shadow-2xl animate-float-delayed">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">5+</div>
                  <div className="text-sm text-gray-400">Years Experience</div>
                </div>
              </div>
            </div>
            
            {/* Background Effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-purple-600/20 to-emerald-500/20 rounded-3xl blur-3xl transform translate-x-8 translate-y-8 -z-10"></div>
            <div className="absolute inset-0 bg-gradient-to-tl from-blue-500/10 via-purple-500/10 to-emerald-400/10 rounded-3xl blur-2xl transform -translate-x-4 -translate-y-4 -z-10"></div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <button
            onClick={scrollToAbout}
            className="p-4 rounded-full bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 hover:bg-gray-700/50 transition-all duration-300 shadow-lg hover:shadow-xl group"
          >
            <ChevronDown size={24} className="text-gray-400 group-hover:text-white transition-colors duration-300" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
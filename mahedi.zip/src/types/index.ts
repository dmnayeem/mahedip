export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
}

export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  category: string;
  image: string;
  results: string[];
  link?: string;
}

export interface PersonalInfo {
  name: string;
  title: string;
  bio: string;
  image: string;
  email: string;
  phone: string;
  location: string;
  skills: string[];
  experience: string;
}

export interface CMSData {
  personalInfo: PersonalInfo;
  services: Service[];
  portfolio: PortfolioItem[];
}
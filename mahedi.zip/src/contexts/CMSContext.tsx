import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CMSData } from '../types';
import { initialData } from '../data/initialData';

interface CMSContextType {
  data: CMSData;
  updateData: (newData: Partial<CMSData>) => void;
  isAdmin: boolean;
  setIsAdmin: (isAdmin: boolean) => void;
}

const CMSContext = createContext<CMSContextType | undefined>(undefined);

export const useCMS = () => {
  const context = useContext(CMSContext);
  if (!context) {
    throw new Error('useCMS must be used within a CMSProvider');
  }
  return context;
};

interface CMSProviderProps {
  children: ReactNode;
}

export const CMSProvider: React.FC<CMSProviderProps> = ({ children }) => {
  const [data, setData] = useState<CMSData>(initialData);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const savedData = localStorage.getItem('cmsData');
    if (savedData) {
      try {
        setData(JSON.parse(savedData));
      } catch (error) {
        console.error('Error loading saved data:', error);
      }
    }
  }, []);

  const updateData = (newData: Partial<CMSData>) => {
    const updatedData = { ...data, ...newData };
    setData(updatedData);
    localStorage.setItem('cmsData', JSON.stringify(updatedData));
  };

  return (
    <CMSContext.Provider value={{ data, updateData, isAdmin, setIsAdmin }}>
      {children}
    </CMSContext.Provider>
  );
};